import 'package:accordion/controllers.dart';
import 'package:flutter/material.dart';
import 'package:accordion/accordion.dart';
import 'package:flutter/services.dart';
import 'neomate.dart';
import 'neomate_html.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_html/flutter_html.dart';
import 'package:html/dom.dart' as dom;
import 'package:url_launcher/url_launcher.dart';
import 'neomate_checklists.dart';
import 'package:page_transition/page_transition.dart';

/*
Need to add license info: https://pub.dev/packages/accordion/versions/1.0.3/install
*/

// Edited accordion_section to remove _isOpen from if (scrollIntoViewOfItems != ScrollIntoViewOfItems.none etc.
// and changed preferPosition: AutoScrollPosition.begin

class AppConstants {
  static var green = const Color.fromRGBO(27, 126, 90, 1);
  static var green_highlight = const Color.fromRGBO(11, 231, 135, 1);
  static var redRow = const Color.fromARGB(255, 254, 222, 222);
  static var colIcon = const Color.fromARGB(255, 255, 255, 255);
  static var blueList = Color.fromRGBO(3, 148, 148, 1);
  static var greyRow = Color.fromRGBO(198, 234, 252, 1);
  static var colChecklistCard = Color.fromRGBO(69, 123, 135, 1);
  static var colChecklistAbstract = Color.fromRGBO(236, 241, 243, 1);
  static List<Color> colChecklist = [
    const Color.fromRGBO(247, 234, 234, 1),
    const Color.fromRGBO(240, 229, 216, 1),
    const Color.fromRGBO(216, 227, 240, 1),
  ];
}

// Icons
class CustomIcons {
  CustomIcons._();
  static const _kFontFam = 'Neomate';
  static const String? _kFontPkg = null;

  static const IconData droplet =
      IconData(0xe800, fontFamily: _kFontFam, fontPackage: _kFontPkg);
  static const IconData heart =
      IconData(0xe801, fontFamily: _kFontFam, fontPackage: _kFontPkg);
  static const IconData head_side_virus =
      IconData(0xe802, fontFamily: _kFontFam, fontPackage: _kFontPkg);
  static const IconData edit =
      IconData(0xe803, fontFamily: _kFontFam, fontPackage: _kFontPkg);
  static const IconData wrench =
      IconData(0xe804, fontFamily: _kFontFam, fontPackage: _kFontPkg);
  static const IconData ok =
      IconData(0xe805, fontFamily: _kFontFam, fontPackage: _kFontPkg);
  static const IconData book =
      IconData(0xf02d, fontFamily: _kFontFam, fontPackage: _kFontPkg);
  static const IconData exclamation_circle =
      IconData(0xf06a, fontFamily: _kFontFam, fontPackage: _kFontPkg);
  static const IconData coffee =
      IconData(0xf0f4, fontFamily: _kFontFam, fontPackage: _kFontPkg);
  static const IconData calc =
      IconData(0xf1ec, fontFamily: _kFontFam, fontPackage: _kFontPkg);
  static const IconData bed =
      IconData(0xf236, fontFamily: _kFontFam, fontPackage: _kFontPkg);
  static const IconData snowflake =
      IconData(0xf2dc, fontFamily: _kFontFam, fontPackage: _kFontPkg);
  static const IconData balance_scale_left =
      IconData(0xf515, fontFamily: _kFontFam, fontPackage: _kFontPkg);
  static const IconData lungs =
      IconData(0xf604, fontFamily: _kFontFam, fontPackage: _kFontPkg);
}

// This is the top level object instance with all the Neomate logic
final neomate = Neomate();

// This is the top level notifer for the above
final neomateNotifier = ChangeNotifierProvider<NeomateModel>(
  (ref) => NeomateModel(),
);

class NeomateModel extends ChangeNotifier {
  bool setWeightGrams(double newWeight) {
    bool retVal = neomate.setWeightGrams(newWeight);
    notifyListeners();
    debugPrint('notified');
    return retVal;
  }

  get weightStringShort => neomate.weightStringShort();
  get weightNumGrams => neomate.weightNumGrams();
  List<Drug> drugList(DrugType myType) => neomate.drugList(myType);
}

void main() {
  runApp(
    const ProviderScope(
      child: MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Neomate',
      theme: ThemeData(
          primarySwatch: Colors.blueGrey,
          colorScheme: ColorScheme.fromSeed(seedColor: Colors.blueGrey)),
      home: const NeomateHome(),
    );
  }
}

class NeomateHome extends StatefulWidget {
  const NeomateHome({Key? key}) : super(key: key);

  @override
  State<NeomateHome> createState() => _NeomateHomeState();
}

class _NeomateHomeState extends State<NeomateHome> {
  int selectedIndex = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Neomate"),
      ),
      body: AnimatedSwitcher(
        duration: const Duration(milliseconds: 400),
        child: IndexedStack(
          index: selectedIndex,
          key: ValueKey<int>(selectedIndex),
          children: [
            NicuCalc(),
            //Clinic(),
            Checklists(),
            References(),
            About(),
          ],
        ),
      ),
      bottomNavigationBar: _neomateNav(),
    );
  }

// Bottom navigation
  Widget _neomateNav() {
    return BottomNavigationBar(
      type: BottomNavigationBarType.fixed,
      backgroundColor: Colors.black,
      selectedItemColor: AppConstants.green_highlight,
      unselectedItemColor: Colors.white,
      selectedFontSize: 12,
      unselectedFontSize: 12,
      currentIndex: selectedIndex,
      onTap: (value) {
        setState(() {
          selectedIndex = value;
        });
        // Respond to item press.
      },
      items: const [
        BottomNavigationBarItem(
          label: 'NICU Calc',
          icon: Icon(Icons.calculate),
        ),
        /*BottomNavigationBarItem(
          label: 'Clinic',
          icon: Icon(Icons.baby_changing_station),
        ),*/
        BottomNavigationBarItem(
          label: 'Checklists',
          icon: Icon(Icons.fact_check),
        ),
        BottomNavigationBarItem(
          label: 'Reference',
          icon: Icon(Icons.book),
        ),
        BottomNavigationBarItem(
          label: 'About',
          icon: Icon(Icons.info_outline),
        ),
      ],
    );
  }
}

class NicuCalc extends StatelessWidget {
  NicuCalc({Key? key}) : super(key: key);

  // This is the calculator page

  @override
  Widget build(BuildContext context) {
    return Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          weightPanel,
          Padding(padding: EdgeInsets.fromLTRB(0, 0, 0, 2)),
          Expanded(child: calcPanel),
        ]);
  }

  final Widget weightPanel = Container(
    decoration: BoxDecoration(color: AppConstants.green),
    //child: Expanded(
    child: Container(
      decoration: BoxDecoration(
        border: Border.all(),
        color: Colors.white,
        borderRadius: const BorderRadius.all(Radius.circular(4)),
      ),
      padding: const EdgeInsets.fromLTRB(10, 0, 10, 0),
      margin: const EdgeInsets.all(10),
      child: WeightForm(),
    ),
    //),
  );

  static const headerStyle = TextStyle(color: Colors.white, fontSize: 15);
  static headerIcon(IconData myIcon) {
    return Icon(myIcon, color: Colors.white, size: 15);
  }

  final Widget calcPanel = Accordion(
    maxOpenSections: 1,
    headerBackgroundColor: AppConstants.green,
    paddingListHorizontal: 4,
    headerBorderRadius: 4,
    contentBorderRadius: 4,
    scrollIntoViewOfItems: ScrollIntoViewOfItems.slow,
    disableScrolling: false,
    rightIcon: Container(),
    contentHorizontalPadding: 0,
    contentVerticalPadding: 0,
    children: [
      AccordionSection(
        isOpen: false,
        contentHorizontalPadding: 0,
        contentVerticalPadding: 0,
        leftIcon: headerIcon(CustomIcons.lungs),
        // ignore: prefer_const_constructors
        header: Text(style: headerStyle, 'Intubation'),
        content: const CalcIntubation(),
      ),
      AccordionSection(
        isOpen: false,
        contentHorizontalPadding: 0,
        contentVerticalPadding: 0,
        leftIcon: headerIcon(CustomIcons.droplet),
        // ignore: prefer_const_constructors
        header: Text(style: headerStyle, 'Central Lines'),
        content: const CalcCentral(),
      ),
      AccordionSection(
        isOpen: false,
        contentHorizontalPadding: 0,
        contentVerticalPadding: 0,
        leftIcon: headerIcon(CustomIcons.heart),
        // ignore: prefer_const_constructors
        header: Text(style: headerStyle, 'Cardiac Drugs'),
        content: const CalcCardiac(),
      ),
      AccordionSection(
        isOpen: false,
        contentHorizontalPadding: 0,
        contentVerticalPadding: 0,
        leftIcon: headerIcon(CustomIcons.bed),
        // ignore: prefer_const_constructors
        header: Text(style: headerStyle, 'Sedative Drugs'),
        content: const CalcSedative(),
      ),
      AccordionSection(
        isOpen: false,
        contentHorizontalPadding: 0,
        contentVerticalPadding: 0,
        leftIcon: headerIcon(CustomIcons.head_side_virus),
        // ignore: prefer_const_constructors
        header: Text(style: headerStyle, 'Neurology Drugs'),
        content: const CalcNeurology(),
      ),
      AccordionSection(
        isOpen: false,
        contentHorizontalPadding: 0,
        contentVerticalPadding: 0,
        leftIcon: headerIcon(CustomIcons.exclamation_circle),
        // ignore: prefer_const_constructors
        header: Text(style: headerStyle, 'Emergency Drugs'),
        content: const CalcEmergency(),
      ),
      AccordionSection(
        isOpen: false,
        contentHorizontalPadding: 0,
        contentVerticalPadding: 0,
        leftIcon: headerIcon(CustomIcons.snowflake),
        // ignore: prefer_const_constructors
        header: Text(style: headerStyle, 'Cooling Criteria'),
        content: htmlWidget(NeomateHtml.cooling),
      ),
      AccordionSection(
        isOpen: false,
        contentHorizontalPadding: 0,
        contentVerticalPadding: 0,
        leftIcon: headerIcon(CustomIcons.edit),
        header:
            // ignore: prefer_const_constructors
            Text(style: headerStyle, 'Admission to Unit'),
        content: Icon(Icons.airplay, size: 70, color: Colors.green[200]),
      ),
      AccordionSection(
        isOpen: false,
        contentHorizontalPadding: 0,
        contentVerticalPadding: 0,
        leftIcon: headerIcon(CustomIcons.coffee),
        header:
            // ignore: prefer_const_constructors
            Text(style: headerStyle, 'Intravenous Fluids'),
        content: CalcIVFluids(),
      ),
      AccordionSection(
        isOpen: false,
        contentHorizontalPadding: 0,
        contentVerticalPadding: 0,
        leftIcon: headerIcon(CustomIcons.lungs),
        header:
            // ignore: prefer_const_constructors
            Text(style: headerStyle, 'Oxygenation Index'),
        content: Icon(CustomIcons.heart, size: 70, color: Colors.green[200]),
      ),
      AccordionSection(
        isOpen: false,
        contentHorizontalPadding: 0,
        contentVerticalPadding: 0,
        leftIcon: headerIcon(CustomIcons.wrench),
        header:
            // ignore: prefer_const_constructors
            Text(style: headerStyle, 'Infusion Calculators'),
        content: Icon(Icons.airplay, size: 70, color: Colors.green[200]),
      ),
    ],
  );
}

class CalcIVFluids extends StatefulWidget {
  CalcIVFluids({Key? key}) : super(key: key);

  @override
  State<CalcIVFluids> createState() => calcIVFluidsState();
}

class calcIVFluidsState extends State<CalcIVFluids> {
  var _dex = 10.0;
  var _sodium = 0.0;
  var _potassium = 0.0;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        const Text('Dextrose'),
        Row(
          children: [
            Flexible(
              fit: FlexFit.tight,
              flex: 3,
              child: Slider(
                min: 5.0,
                max: 30.0,
                divisions: 10,
                value: _dex,
                onChanged: (value) {
                  setState(() {
                    _dex = value;
                  });
                },
              ),
            ),
            Flexible(
              fit: FlexFit.tight,
              flex: 2,
              child: Text('${_dex.toString().replaceAll('.0', '')} %'),
            ),
          ],
        ),
        const Text('Sodium'),
        Row(
          children: [
            Flexible(
              fit: FlexFit.tight,
              flex: 3,
              child: Slider(
                min: 0.0,
                max: 10.0,
                divisions: 20,
                value: _sodium,
                onChanged: (value) {
                  setState(() {
                    _sodium = value;
                  });
                },
              ),
            ),
            Flexible(
              fit: FlexFit.tight,
              flex: 2,
              child: Text(
                  '${_sodium.toString().replaceAll('.0', '')} mmol/kg/day'),
            ),
          ],
        ),
        Text('Potassium'),
        Row(
          children: [
            Flexible(
              fit: FlexFit.tight,
              flex: 3,
              child: Slider(
                min: 0.0,
                max: 30.0,
                divisions: 20,
                value: _potassium,
                onChanged: (value) {
                  setState(() {
                    _potassium = value;
                  });
                },
              ),
            ),
            Flexible(
              fit: FlexFit.tight,
              flex: 2,
              child: Text(
                  '${_potassium.toString().replaceAll('.0', '')} mmol/kg/day'),
            ),
          ],
        ),
      ],
    );
    ;
  }
}

class CalcIntubation extends StatelessWidget {
  const CalcIntubation({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const BolusDrugs(selectedDrugs: DrugType.intubation);
  }
}

class CalcCentral extends StatelessWidget {
  const CalcCentral({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const BolusDrugs(selectedDrugs: DrugType.central);
  }
}

class CalcCardiac extends StatelessWidget {
  const CalcCardiac({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const BolusDrugs(selectedDrugs: DrugType.cardiac);
  }
}

class CalcSedative extends StatelessWidget {
  const CalcSedative({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const BolusDrugs(selectedDrugs: DrugType.sedative);
  }
}

class CalcNeurology extends StatelessWidget {
  const CalcNeurology({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const BolusDrugs(selectedDrugs: DrugType.neurology);
  }
}

class CalcEmergency extends StatelessWidget {
  const CalcEmergency({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const BolusDrugs(selectedDrugs: DrugType.emergency);
  }
}

/// * Widgets for displaying lists of bolus drugs and infusions *

class BolusDrugs extends ConsumerWidget {
  // Build a list of drugs and return a column of rows that contain the formatted drug information

  final DrugType selectedDrugs;

  const BolusDrugs({
    Key? key,
    required this.selectedDrugs,
  }) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final notifier = ref.watch(neomateNotifier);
    List<Drug> myDrugs = notifier.drugList(selectedDrugs);
    List<Widget> drugRows = [];
    bool redRow = true;

    for (var drug in myDrugs) {
      if (drug is DrugMultiplier) {
        // Row to display drug based on a multiple of the weight
        drugRows.add(Container(
          color: redRow ? AppConstants.redRow : Colors.transparent,
          child: Padding(
            padding: const EdgeInsets.all(5),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Name and dose column
                Expanded(
                  flex: 2,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        drug.name,
                        style: const TextStyle(fontSize: 16),
                      ),
                      const Padding(padding: EdgeInsets.fromLTRB(0, 3, 0, 2)),
                      Text(
                        '(${drug.dose})',
                        style: const TextStyle(fontSize: 13),
                      ),
                    ],
                  ),
                ),
                const Padding(padding: EdgeInsets.fromLTRB(3, 0, 3, 0)),
                // Calculated dose and instructions column
                Expanded(
                  flex: 3,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    //children: drugDetail(drug),
                    children: List.from(drugDetailInner(drug))
                      ..addAll([
                        const Padding(padding: EdgeInsets.fromLTRB(0, 3, 0, 2)),
                        Text(
                          drug.notes,
                          style: const TextStyle(
                              fontSize: 12, fontStyle: FontStyle.italic),
                        )
                      ]),
                  ),
                ),
              ],
            ),
          ),
        ));
        redRow = !redRow;
      }
      if (drug is DrugBanded) {
        // Row to display drug based on bandings of the weight
        drugRows.add(Container(
          color: redRow ? AppConstants.redRow : Colors.transparent,
          child: Padding(
            padding: const EdgeInsets.all(5),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Name and dose column
                Expanded(
                  flex: 2,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        drug.name,
                        style: const TextStyle(fontSize: 16),
                      ),
                      const Padding(padding: EdgeInsets.fromLTRB(0, 3, 0, 2)),
                    ],
                  ),
                ),
                const Padding(padding: EdgeInsets.fromLTRB(3, 0, 3, 0)),
                // Calculated dose and instructions column
                Expanded(
                  flex: 3,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: List.from(drugDetailInner(drug))
                      ..addAll([
                        const Padding(padding: EdgeInsets.fromLTRB(0, 3, 0, 2)),
                        Text(
                          drug.notes,
                          style: const TextStyle(
                              fontSize: 12, fontStyle: FontStyle.italic),
                        )
                      ]),
                  ),
                ),
              ],
            ),
          ),
        ));
        redRow = !redRow;
      }
      if (drug is DrugInfo) {
        // Row to display drug that's information only
        drugRows.add(Container(
          color: redRow ? AppConstants.redRow : Colors.transparent,
          child: Padding(
            padding: const EdgeInsets.all(5),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Name and dose column
                Expanded(
                  flex: 2,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        drug.name,
                        style: const TextStyle(fontSize: 16),
                      ),
                      const Padding(padding: EdgeInsets.fromLTRB(0, 3, 0, 2)),
                      Text(
                        drug.qualifier,
                        style: const TextStyle(fontSize: 12),
                      ),
                    ],
                  ),
                ),
                const Padding(padding: EdgeInsets.fromLTRB(3, 0, 3, 0)),
                // Calculated dose and instructions column
                Expanded(
                  flex: 3,
                  child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text.rich(TextSpan(children: [
                          TextSpan(
                            text: '${drug.calcString} ',
                            style: const TextStyle(
                                fontSize: 14, fontWeight: FontWeight.w500),
                          ),
                          TextSpan(
                            text: '${drug.units} ',
                            style: const TextStyle(
                                fontSize: 14, fontWeight: FontWeight.w500),
                          ),
                          TextSpan(
                            text: drug.instructions,
                            style: const TextStyle(fontSize: 13),
                          ),
                        ])),
                        const Padding(padding: EdgeInsets.fromLTRB(0, 3, 0, 2)),
                        Text(
                          drug.notes,
                          style: const TextStyle(
                              fontSize: 12, fontStyle: FontStyle.italic),
                        )
                      ]),
                ),
              ],
            ),
          ),
        ));
        redRow = !redRow;
      }
      if (drug is DrugFormula) {
        // Row to display drug that's information only
        drugRows.add(Container(
          color: redRow ? AppConstants.redRow : Colors.transparent,
          child: Padding(
            padding: const EdgeInsets.all(5),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Name and dose column
                Expanded(
                  flex: 2,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        drug.name,
                        style: const TextStyle(fontSize: 16),
                      ),
                      const Padding(padding: EdgeInsets.fromLTRB(0, 3, 0, 2)),
                      Text(
                        drug.qualifier,
                        style: const TextStyle(fontSize: 12),
                      ),
                    ],
                  ),
                ),
                const Padding(padding: EdgeInsets.fromLTRB(3, 0, 3, 0)),
                // Calculated dose and instructions column
                Expanded(
                  flex: 3,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(drug.calcFormula),
                      const Padding(
                        padding: EdgeInsets.fromLTRB(0, 4, 0, 0),
                      ),
                      Text.rich(TextSpan(children: [
                        TextSpan(
                          text: '= ${drug.calcString} ',
                          style: const TextStyle(
                              fontSize: 14, fontWeight: FontWeight.w500),
                        ),
                        TextSpan(
                          text: '${drug.units} ',
                          style: const TextStyle(
                              fontSize: 14, fontWeight: FontWeight.w500),
                        ),
                        TextSpan(
                          text: '${drug.instructions}',
                          style: const TextStyle(fontSize: 13),
                        ),
                      ]))
                    ],
                  ),
                ),
              ],
            ),
          ),
        ));
        redRow = !redRow;
      }
      if (drug is DrugInfusion) {
        // Row to display drug that's information only
        drugRows.add(Container(
          color: redRow ? AppConstants.redRow : Colors.transparent,
          child: Padding(
            padding: const EdgeInsets.all(5),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '${drug.name} infusion',
                  style: const TextStyle(fontSize: 16),
                ),
                const Padding(padding: EdgeInsets.fromLTRB(0, 5, 0, 0)),
                Text(
                  drug.calcPreNarrative,
                  style: const TextStyle(fontSize: 14),
                ),
                const Padding(padding: EdgeInsets.fromLTRB(0, 10, 0, 0)),
                Center(
                  child: Container(
                    padding: const EdgeInsets.fromLTRB(0, 0, 0, 4),
                    decoration: const BoxDecoration(
                      border: Border(
                        bottom: BorderSide(
                            width: 1.5, color: Color.fromRGBO(54, 54, 54, 0.6)),
                      ),
                    ),
                    child: FittedBox(
                      fit: BoxFit.scaleDown,
                      child: Text(
                        drug.calcTop,
                        style: const TextStyle(fontSize: 12),
                      ),
                    ),
                  ),
                ),
                const Padding(padding: EdgeInsets.fromLTRB(0, 6, 0, 0)),
                Center(
                  child: FittedBox(
                    fit: BoxFit.scaleDown,
                    child: Text(
                      drug.calcBottom,
                      style: const TextStyle(fontSize: 12),
                    ),
                  ),
                ),
                const Padding(padding: EdgeInsets.fromLTRB(0, 10, 0, 0)),
                Text(
                  drug.calcPostNarrative,
                  style: const TextStyle(fontSize: 14),
                ),
                const Padding(padding: EdgeInsets.fromLTRB(0, 5, 0, 0)),
                Text(
                  drug.doseMsg,
                  style: const TextStyle(fontSize: 14),
                ),
                const Padding(padding: EdgeInsets.fromLTRB(0, 5, 0, 0)),
              ],
            ),
          ),
        ));
        redRow = !redRow;
      }
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      mainAxisAlignment: MainAxisAlignment.start,
      children: drugRows,
    );
  }

  List<Widget> drugDetailInner(Drug drug) {
    // Recursive method to unwrap a list of follow-on doses and display nicely
    List<Widget> ret = [
      Text.rich(TextSpan(children: [
        (drug.qualifier == '')
            ? const TextSpan(text: '')
            : TextSpan(
                text: '${drug.qualifier}:\n',
                style: const TextStyle(fontSize: 13),
              ),
        TextSpan(
          text: '${drug.calcString} ',
          style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w500),
        ),
        TextSpan(
          text: '${drug.units} ',
          style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w500),
        ),
        TextSpan(
          text: drug.instructions,
          style: const TextStyle(fontSize: 13),
        ),
      ]))
    ];
    if (drug.followOn is Drug) {
      ret.add(const Padding(padding: EdgeInsets.fromLTRB(0, 2, 0, 2)));
      ret.addAll(drugDetailInner(drug.followOn!));
    }
    return ret;
  }
}

/// * Widgets for inputting and displaying weight *

class WeightForm extends ConsumerWidget {
  WeightForm({Key? key}) : super(key: key);
  final _weightInput = GlobalKey<FormFieldState>();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final notifier = ref.watch(neomateNotifier);
    var initVal = "";
    if (notifier.weightStringShort != "NaN") {
      initVal = notifier.weightStringShort;
    }

    return Row(children: <Widget>[
      Flexible(
        flex: 1,
        fit: FlexFit.loose,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(0, 5, 0, 5),
          child: TextFormField(
            key: _weightInput,
            initialValue: initVal,
            decoration: InputDecoration(
              constraints: BoxConstraints.loose(const Size.fromHeight(30)),
              contentPadding: const EdgeInsets.fromLTRB(5, 0, 5, 0),
              border: const OutlineInputBorder(),
            ),
            textAlign: TextAlign.right,
            keyboardType: TextInputType.number,
            inputFormatters: [
              FilteringTextInputFormatter.digitsOnly,
              LengthLimitingTextInputFormatter(4),
            ],
          ),
        ),
      ),
      const Padding(padding: EdgeInsets.fromLTRB(0, 0, 10, 0)),
      const Flexible(
        flex: 1,
        child: Text('grams'),
      ),
      const Padding(padding: EdgeInsets.fromLTRB(10, 0, 10, 0)),
      Flexible(
        flex: 2,
        fit: FlexFit.tight,
        child: ConstrainedBox(
          constraints: BoxConstraints.loose(const Size.fromHeight(30)),
          child: ElevatedButton(
            onPressed: () {
              String outcome = "";
              if (_weightInput.currentState!.value != null) {
                double? tempWeight =
                    double.tryParse(_weightInput.currentState!.value);
                if (tempWeight is double) {
                  if (tempWeight < Neomate.minWeightGrams) {
                    outcome = "Weight too low - please recheck";
                  } else if (tempWeight > Neomate.maxWeightGrams) {
                    outcome =
                        "Weight too high - please recheck - this app is for neonatal patients only";
                  } else {
                    ref.read(neomateNotifier).setWeightGrams(tempWeight);
                    FocusScope.of(context).unfocus();
                    outcome = "Parameters calculated";
                  }
                } else {
                  outcome = "That's not a valid weight - please recheck";
                }
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(outcome),
                  ),
                );
              }
            },
            child: const FittedBox(
              fit: BoxFit.scaleDown,
              child: Text('Calculate'),
            ),
          ),
        ),
      ),
      const Padding(padding: EdgeInsets.fromLTRB(10, 0, 10, 0)),
      Flexible(
        flex: 2,
        fit: FlexFit.tight,
        child: ConstrainedBox(
          constraints: BoxConstraints.loose(const Size.fromHeight(30)),
          child: ElevatedButton(
            onPressed: () {},
            child: const FittedBox(
              fit: BoxFit.scaleDown,
              child: Text('Gestation'),
            ),
          ),
        ),
      ),
    ]);
    //);
  }
}

class Clinic extends StatelessWidget {
  const Clinic({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Text("Clinic");
  }
}

class Checklists extends StatelessWidget {
  const Checklists({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ChecklistPage();
  }
}

class References extends StatelessWidget {
  const References({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ReferencePage();
  }
}

class About extends StatelessWidget {
  const About({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
        child: Column(
      children: [htmlWidget(NeomateHtml.aboutPage), const AboutListTile()],
    ));
  }
}

// Checklists

class ChecklistPage extends StatefulWidget {
  ChecklistPage({Key? key}) : super(key: key);

  @override
  State<ChecklistPage> createState() => _ChecklistPageState();
}

class _ChecklistPageState extends State<ChecklistPage> {
  final keyOne = GlobalKey<NavigatorState>();

  Widget _menu(BuildContext context) {
    List<Widget> checklistPages = [
      Container(
        padding: const EdgeInsets.fromLTRB(10, 5, 10, 5),
        child: htmlWidget(NeomateHtml.checklistPreamble),
      ),
    ];
    for (var checklist in checklistDb) {
      checklistPages.add(
        Card(
          color: AppConstants.colChecklistCard,
          child: ListTile(
            title: Text(
              checklist.heading,
              style: const TextStyle(color: Colors.white),
            ),
            subtitle: Text(
              checklist.subheading,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 12,
              ),
            ),
            isThreeLine: true,
            onTap: () {
              Navigator.of(context).push(
                PageTransition(
                  type: PageTransitionType.rightToLeft,
                  child: _checklistPage(checklist),
                ),
              );
            },
          ),
        ),
      );
    }
    checklistPages
        .add(const Padding(padding: EdgeInsets.fromLTRB(0, 0, 0, 10)));
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          padding: const EdgeInsets.fromLTRB(10, 10, 0, 0),
          child: const Text(
            'Neonatal Checklists',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
          ),
        ),
        Flexible(
          child: ListView(children: checklistPages),
        ),
      ],
    );
  }

  Widget _checklistPage(Checklist checklist) {
    List<Widget> checklistSections = [
      Container(
        color: AppConstants.colChecklistAbstract,
        child: Padding(
          padding: EdgeInsets.fromLTRB(10, 5, 10, 5),
          child: htmlWidget(checklist.abstract),
        ),
      ),
      const Padding(padding: EdgeInsets.fromLTRB(0, 10, 0, 0)),
    ];

    var sectionNum = 0;

    for (var section in checklist.sections) {
      sectionNum++;
      checklistSections.add(
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(10, 5, 0, 0),
              child: (checklist.sections.length < 2)
                  ? Container()
                  : Text(
                      '$sectionNum. ${section.sectionHeading}',
                      style: const TextStyle(
                          color: Colors.black, fontWeight: FontWeight.bold),
                    ),
            ),
            const Padding(
              padding: EdgeInsets.fromLTRB(0, 5, 0, 0),
            ),
            _checklistItems(
                section,
                AppConstants.colChecklist[
                    sectionNum % AppConstants.colChecklist.length]),
            const Padding(padding: EdgeInsets.fromLTRB(0, 5, 0, 0)),
          ],
        ),
      );
    }

    return Container(
      color: Colors.white,
      child: Column(
        children: [
          Row(children: [
            const BackButton(),
            Expanded(
              child: Text(
                checklist.heading,
                style:
                    const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
            ),
          ]),
          Flexible(
            child: ListView(children: checklistSections),
          ),
        ],
      ),
    );
  }

  Widget _checklistItems(ChecklistSection section, Color color) {
    List<Widget> items = [];

    for (var item in section.items) {
      var myKey = GlobalKey<_ChecklistCheckboxState>();
      items.add(
        Card(
          margin: EdgeInsets.fromLTRB(12, 5, 12, 5),
          color: color,
          child: InkWell(
            onTap: () {
              myKey.currentState!.flip();
            },
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: (item.length < 150)
                  ? CrossAxisAlignment.center
                  : CrossAxisAlignment.start,
              children: [
                ChecklistCheckbox(key: myKey),
                Expanded(
                  child: Padding(
                    padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
                    child: htmlWidget(item),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    }
    return Column(
        crossAxisAlignment: CrossAxisAlignment.stretch, children: items);
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      child: WillPopScope(
        onWillPop: () async => !await keyOne.currentState!.maybePop(),
        child: Navigator(
            key: keyOne,
            onGenerateRoute: (routeSettings) {
              return MaterialPageRoute(
                builder: (context) => _menu(context),
              );
            }),
      ),
    );
  }
}

class ChecklistCheckbox extends StatefulWidget {
  const ChecklistCheckbox({Key? key}) : super(key: key);

  @override
  State<ChecklistCheckbox> createState() => _ChecklistCheckboxState();
}

class _ChecklistCheckboxState extends State<ChecklistCheckbox> {
  bool isChecked = false;

  void flip() {
    setState(() {
      isChecked = !isChecked;
    });
  }

  @override
  Widget build(
    BuildContext context,
  ) {
    Color getColor(Set<MaterialState> states) {
      const Set<MaterialState> interactiveStates = <MaterialState>{
        MaterialState.pressed,
        MaterialState.hovered,
        MaterialState.focused,
      };
      if (states.any(interactiveStates.contains)) {
        return Colors.blue;
      }
      return Colors.grey;
    }

    return Checkbox(
      checkColor: Colors.white,
      fillColor: MaterialStateProperty.resolveWith(getColor),
      value: isChecked,
      onChanged: (bool? value) {
        setState(() {
          isChecked = value!;
        });
      },
    );
  }
}

// Reference pages

class ReferencePage extends StatefulWidget {
  ReferencePage({Key? key}) : super(key: key);

  @override
  State<ReferencePage> createState() => _ReferencePageState();
}

class _ReferencePageState extends State<ReferencePage> {
  final keyOne = GlobalKey<NavigatorState>();

  Widget _menu(BuildContext context) {
    List<Widget> referencePages = [
      Container(
        padding: const EdgeInsets.fromLTRB(10, 5, 10, 5),
        child: htmlWidget(NeomateHtml.checklistPreamble),
      ),
    ];
    for (var reference in referenceDb) {
      referencePages.add(
        Card(
          color: AppConstants.colChecklistCard,
          child: ListTile(
            title: Text(
              reference.heading,
              style: const TextStyle(color: Colors.white),
            ),
            subtitle: Text(
              reference.subheading,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 12,
              ),
            ),
            isThreeLine: true,
            onTap: () {
              Navigator.of(context).push(
                PageTransition(
                  type: PageTransitionType.rightToLeft,
                  child: _referencePage(reference),
                ),
              );
            },
          ),
        ),
      );
    }
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          padding: const EdgeInsets.fromLTRB(10, 10, 0, 0),
          child: const Text(
            'Neonatal References',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
          ),
        ),
        Flexible(
          child: ListView(children: referencePages),
        ),
      ],
    );
  }

  Widget _referencePage(Reference reference) {
    List<Widget> referenceSections = [
      Container(
        color: AppConstants.colChecklistAbstract,
        child: Padding(
          padding: EdgeInsets.fromLTRB(10, 5, 10, 5),
          child: htmlWidget(reference.abstract),
        ),
      ),
      const Padding(padding: EdgeInsets.fromLTRB(0, 10, 0, 0)),
    ];

    var sectionNum = 0;

    for (var section in reference.sections) {
      sectionNum++;
      referenceSections.add(
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(10, 10, 10, 10),
              child: Card(
                color: AppConstants.colChecklist[
                    sectionNum % AppConstants.colChecklist.length],
                child: Padding(
                  padding: EdgeInsets.fromLTRB(10, 5, 10, 5),
                  child: htmlWidget(section),
                ),
              ),
            ),
          ],
        ),
      );
    }

    referenceSections
        .add(const Padding(padding: EdgeInsets.fromLTRB(0, 10, 0, 0)));

    return Container(
      color: Colors.white,
      child: Column(
        children: [
          Row(children: [
            const BackButton(),
            Flexible(
              child: Text(
                reference.heading,
                style:
                    const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
            ),
          ]),
          Flexible(
            child: ListView(children: referenceSections),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      child: WillPopScope(
        onWillPop: () async => !await keyOne.currentState!.maybePop(),
        child: Navigator(
            key: keyOne,
            onGenerateRoute: (routeSettings) {
              return MaterialPageRoute(
                builder: (context) => _menu(context),
              );
            }),
      ),
    );
  }
}

// functions for rendering html widgets and handling urls

Widget htmlWidget(data) {
  return Html(
      data: data,
      style: {
        // p tag with text_size
        "p": Style(
          fontSize: const FontSize(13),
        ),
        "h1": Style(
          fontSize: const FontSize(15),
        ),
        "h2": Style(
          fontSize: const FontSize(14),
        ),
        "h3": Style(
          fontSize: const FontSize(14),
        ),
        "ul": Style(
          fontSize: const FontSize(13),
        ),
        "ul": Style(
          fontSize: const FontSize(13),
          padding: const EdgeInsets.fromLTRB(10, 5, 0, 5),
        ),
        "ol": Style(
          fontSize: const FontSize(13),
          padding: const EdgeInsets.fromLTRB(10, 0, 0, 0),
        ),
        "li": Style(
          fontSize: const FontSize(13),
          padding: const EdgeInsets.fromLTRB(0, 0, 0, 4),
        ),
        "img": Style(
          padding: const EdgeInsets.fromLTRB(10, 10, 10, 10),
        ),
      },
      onLinkTap: (String? url, RenderContext context,
          Map<String, String> attributes, dom.Element? element) {
        print("tap");
        if (url is String) {
          doLaunchUrl(Uri.parse(url));
        }
      });
}

void doLaunchUrl(Uri url) async {
  // Launch URL as an async task
  if (!await launchUrl(url)) throw 'Could not launch $url';
}
