///
///
///   Neomate 2.0
///
///   Original app by Christopher Kelly
///
///   Reimplemented for Dart/Flutter by Lee Collier
///
///

// Define some classes for [bolus] drugs and infusions

void main() {
  var myNeo = Neomate();
  myNeo.setWeightGrams(1500);
  var myList = myNeo.drugList(DrugType.intubation);
  print("${myList.length}");
}

enum DrugType {
  intubation,
  central,
  cardiac,
  sedative,
  neurology,
  emergency,
  generic,
}

enum FluidType {
  // ignore: constant_identifier_names
  NS,
  // ignore: constant_identifier_names
  D5W,
}

class Infusion {
  List<DrugType> types;
  List<FluidType> fluids;
  String name;
  String units;
  double startDose;
  double desiredRate;
  double syringe;
  double minConc;
  double maxConc;
  String minConcMsg;
  String maxConcMsg;
  double minDose;
  double maxDose;
  String doseMsg;

  Infusion({
    required this.types,
    required this.name,
    required this.units,
    required this.startDose,
    required this.fluids,
    required this.desiredRate,
    required this.syringe,
    required this.minConc,
    required this.maxConc,
    required this.minConcMsg,
    required this.maxConcMsg,
    required this.minDose,
    required this.maxDose,
    required this.doseMsg,
  });
}

class Drug {
  final List<DrugType> types;
  final String name;
  final String dose;
  final String qualifier;
  final double multiplier;
  final String units;
  final String instructions;
  final String notes;
  final Drug? followOn;
  final bool noCalc;
  final double? weight;

  static final invalid = Drug(
    // We will use this static instance if we need to 'delete' a drug object
    types: [],
    name: '?',
    dose: '?',
    multiplier: 0,
    units: '?',
    instructions: '?',
  );

  Drug({
    required this.types,
    required this.name,
    required this.dose,
    this.qualifier = '',
    required this.multiplier,
    required this.units,
    required this.instructions,
    this.followOn,
    this.notes = '',
    this.noCalc = false,
    this.weight,
  });

  Drug bindWeight(double myWeight) {
    if (weight is double) {
      // If a weight is already bound then something is wrong, so return the invalid static instance
      return invalid;
    } else {
      // Build a new instance with the weight bound in
      return Drug(
        types: types,
        name: name,
        dose: dose,
        qualifier: qualifier,
        multiplier: multiplier,
        units: units,
        instructions: instructions,
        notes: notes,
        followOn: (followOn == null) ? null : followOn!.bindWeight(myWeight),
        noCalc: noCalc,
        weight: myWeight,
      );
    }
  }

  String calcString() {
    if (weight is double) {
      if (weight!.isNaN) {
        return '?';
      }
      double calcDose = weight! * multiplier;
      if (calcDose < 0.01) {
        return 'Too low';
      }
      if (calcDose > 1000) {
        return 'Too high';
      }
      if (calcDose < 0.1) {
        return calcDose.toStringAsFixed(3);
      }
      if (calcDose < 1) {
        return calcDose.toStringAsFixed(2);
      }
      if (calcDose < 100) {
        return calcDose.toStringAsFixed(1);
      } else {
        return calcDose.round().toString();
      }
    } else {
      return '?';
    }
  }
}

class Neomate {
  List<Infusion> infusionDb = [];
  List<Drug> drugDb = [];
  double fiO2 = double.nan;
  double MAP = double.nan;
  double paO2 = double.nan;
  double babyWeight = double.nan;
  Map<int, double> weightEstimates = {};
  bool weightIsEst = false;

  static double minWeight = 0.2;
  static double maxWeight = 6.0;
  static double minWeightGrams = 200;
  static double maxWeightGrams = 6000;

  Neomate() {
    drugDb = [
      // Intubation Drugs
      Drug(
        types: [
          DrugType.intubation,
          DrugType.sedative,
        ],
        name: 'Fentanyl bolus',
        dose: '5 mcg/kg',
        multiplier: 5,
        units: 'micrograms',
        instructions: 'by slow IV push',
        notes: 'preferred drug for intubation',
      ),
      Drug(
        types: [
          DrugType.intubation,
          DrugType.sedative,
        ],
        name: 'Morphine bolus',
        dose: '100 mcg/kg',
        multiplier: 100,
        units: 'micrograms',
        instructions: 'by slow IV push',
        notes: 'onset of action approx 15 minutes; peak action at 15-30 mins',
      ),
      Drug(
        types: [DrugType.intubation],
        name: 'Atropine',
        dose: '20 mcg/kg',
        multiplier: 20,
        units: 'micrograms',
        instructions: 'by slow IV push',
      ),
      Drug(
        types: [DrugType.intubation],
        name: 'Suxamethonium',
        dose: '2 mg/kg',
        multiplier: 2,
        units: 'mg',
        instructions: 'by slow IV push',
      ),
      Drug(
        types: [DrugType.intubation],
        name: 'Poractant Alfa (Curosurf \u24c7)',
        dose: '200 mg/kg',
        qualifier: 'First dose: ',
        multiplier: 200,
        units: 'mg',
        instructions: 'via ET tube',
        notes: 'consider giving nearest whole vial',
        followOn: Drug(
          types: [DrugType.intubation],
          name: 'Poractant Alfa (Curosurf \u24c7)',
          dose: '100 mg/kg',
          qualifier: 'Second dose: ',
          multiplier: 100,
          units: 'mg',
          instructions: 'via ET tube',
        ),
      ),
      // Cardiac Drugs
      Drug(
          types: [DrugType.cardiac],
          name: '0.9% NaCl Bolus',
          dose: '10 mL/kg',
          multiplier: 10,
          units: 'mL',
          instructions: 'over 20-30 minutes IV'),
      // Sedative Drugs
      // Fentayl and Morphine already included under intubation
      Drug(
        types: [DrugType.sedative],
        name: 'Pancuronium Bolus',
        dose: '100 mcg/kg',
        multiplier: 100,
        units: 'micrograms',
        instructions: 'by slow IV push',
        notes: 'for longer duration of action',
      ),
      Drug(
        types: [DrugType.sedative],
        name: 'Vecuronium Bolus',
        dose: '100 mcg/kg',
        multiplier: 100,
        units: 'micrograms',
        instructions: 'by slow IV push',
        notes: 'for shorter duration of action',
      ),
      // Neurology Drugs
      Drug(
        types: [DrugType.neurology],
        name: 'Phenobarbital',
        dose: 'Loading dose 20 mg/kg',
        multiplier: 20,
        units: 'mg',
        instructions: 'given IV over 20 minutes',
        qualifier: 'loading dose',
        followOn: Drug(
          types: [DrugType.neurology],
          name: 'Phenobarbital',
          dose: '10 mg/kg',
          multiplier: 10,
          units: 'mg',
          instructions: 'given IV over 20 minutes',
          qualifier: 'subsequent dose',
        ),
      ),
      Drug(
        types: [DrugType.neurology],
        name: 'Midazolam Bolus',
        dose: '300 mcg/kg',
        multiplier: 300,
        units: 'micrograms',
        instructions: 'given IV over 5 minutes',
        notes: 'further dose after 10 minutes if required',
      ),
      // Emergency Drugs
      Drug(
        types: [DrugType.emergency],
        name: 'Adrenaline 1:10000',
        dose: '0.2 mL/kg',
        multiplier: 0.2,
        units: 'mL',
        instructions: 'give IV stat then flush with 0.9% sodium chloride',
      ),
      Drug(
        types: [DrugType.emergency],
        name: 'Dextrose 10% bolus',
        dose: '2.5 mL/kg',
        multiplier: 2.5,
        units: 'mL',
        instructions: 'give IV over 20-30 minutes',
      ),
      Drug(
        types: [DrugType.emergency],
        name: 'Sodium bicarbonate 4.2%',
        dose: '2 mL/kg',
        qualifier: '1 mmol/kg for emergency resuscitation',
        multiplier: 2,
        units: 'mL',
        instructions: 'of sodium bicarbonate 4.2% via central line',
        notes:
            'double check concentration, 4.2% and 8.4% forms are easily confused',
      ),
      Drug(
        types: [DrugType.emergency],
        name: 'Sodium bicarbonate',
        noCalc: true,
        dose: '',
        qualifier: 'full correction',
        multiplier: 0,
        units: '',
        instructions: 'Base deficit (mmol/L) x 0.6 x weight',
        notes:
            'Initially give half the above. Sodium bicarbonate 4.2% diluted with equal part water given IV over 30 minutes',
      ),
      Drug(
        types: [DrugType.emergency],
        name: 'Adenosine',
        dose: '150 mcg/kg',
        multiplier: 150,
        units: 'micrograms',
        instructions:
            'IV stat into a large central vein followed immediately by a NaCl 0.9% flush',
        notes: 'escalating doses may be required',
      ),
    ];

    final infusionDb = [
      Infusion(
          types: [DrugType.cardiac],
          name: 'dopamine',
          units: 'mcg/kg/min',
          startDose: 5,
          fluids: [FluidType.D5W, FluidType.NS],
          desiredRate: 1,
          syringe: 50,
          minConc: 0,
          maxConc: 80,
          minConcMsg: '',
          maxConcMsg:
              'Concentrations higher than 1.6 mg/ml are not recommended, unless infused centrally (BNFc 2015).',
          minDose: 5,
          maxDose: 20,
          doseMsg: 'Usual dose 5-20 mcg/kg/min, <b>via central line</b>.'),
      Infusion(
          types: [DrugType.cardiac],
          name: 'dobutamine',
          units: 'mcg/kg/min',
          startDose: 5,
          fluids: [FluidType.D5W, FluidType.NS],
          desiredRate: 1,
          syringe: 50,
          minConc: 0,
          maxConc: 500,
          minConcMsg: '',
          maxConcMsg:
              'Concentrations higher than 10mg/ml are not commonly used (Medusa 2015)',
          minDose: 2,
          maxDose: 20,
          doseMsg: 'Usual dose 2-20 mcg/kg/min, via central line'),
      Infusion(
          types: [DrugType.cardiac],
          name: 'adrenaline',
          units: 'ng/kg/min',
          startDose: 100,
          fluids: [FluidType.D5W, FluidType.NS],
          desiredRate: 0.1,
          syringe: 50,
          minConc: 0,
          maxConc: 12,
          minConcMsg: '',
          maxConcMsg:
              'Infusions of >12mg in 50ml are not usually recommended (Medusa 2015).',
          minDose: 50,
          maxDose: 500,
          doseMsg: 'Usual dose 50-500 nanograms/kg/min, via central line'),
      Infusion(
          types: [DrugType.cardiac],
          name: 'noradrenaline',
          units: 'ng/kg/min',
          startDose: 100,
          fluids: [FluidType.D5W, FluidType.NS],
          desiredRate: 0.1,
          syringe: 50,
          minConc: 0,
          maxConc: 2,
          minConcMsg: '',
          maxConcMsg:
              'Higher than recommended concentration: max. 40 micrograms/mL (higher concentrations can be used if fluid restricted) - BNFc Jan 2015.',
          minDose: 50,
          maxDose: 500,
          doseMsg: 'Usual dose 50-500 nanograms/kg/min, via central line'),
      Infusion(
          types: [DrugType.cardiac],
          name: 'dinoprostone',
          units: 'ng/kg/min',
          startDose: 10,
          fluids: [FluidType.D5W, FluidType.NS],
          desiredRate: 1,
          syringe: 50,
          minConc: 0,
          maxConc: 0.05,
          minConcMsg: '',
          maxConcMsg:
              'Higher than recommended concentration: BNFc recommends dilution to 1 microgram/mL.',
          minDose: 1,
          maxDose: 20,
          doseMsg: 'Usual dose 5-10 nanograms/kg/min'),
      Infusion(
          types: [DrugType.sedative],
          name: 'morphine',
          units: 'mcg/kg/hr',
          startDose: 20,
          fluids: [FluidType.D5W, FluidType.NS],
          desiredRate: 1,
          syringe: 50,
          minConc: 0,
          maxConc: 1500,
          minConcMsg: '',
          maxConcMsg: 'Higher than recommended concentration.',
          minDose: 0,
          maxDose: 60,
          doseMsg: 'Usual dose 5-20 mcg/kg/hr, but higher doses may be used.'),
      Infusion(
          types: [DrugType.sedative],
          name: 'vecuronium',
          units: 'mcg/kg/hr',
          startDose: 100,
          fluids: [FluidType.D5W, FluidType.NS],
          desiredRate: 1,
          syringe: 50,
          minConc: 4,
          maxConc: 200,
          minConcMsg:
              'Too dilute: Do not dilute to a concentration of less than 40micrograms in 1mL. (BNF for Children January 2015)',
          maxConcMsg:
              'Higher than recommended concentration: Dilute to an ideal maximum concentration of 2mg in 1mL. (BNF for Children January 2015)',
          minDose: 50,
          maxDose: 200,
          doseMsg: 'Usual dose 50-200 mcg/kg/hr'),
      Infusion(
          types: [DrugType.neurology],
          name: 'clonazepam',
          units: 'mcg/kg/hr',
          startDose: 10,
          fluids: [FluidType.D5W, FluidType.NS],
          desiredRate: 1,
          syringe: 50,
          minConc: 0,
          maxConc: 0.6,
          minConcMsg: '',
          maxConcMsg:
              'Higher than recommended concentration: Dilute to a maximum concentration of 12micrograms in 1mL. (Medusa 2015)',
          minDose: 10,
          maxDose: 40,
          doseMsg: 'Usual dose 10-40 mcg/kg/hr'),
      Infusion(
          types: [DrugType.neurology],
          name: 'midazolam',
          units: 'mcg/kg/hr',
          startDose: 30,
          fluids: [FluidType.D5W, FluidType.NS],
          desiredRate: 0.1,
          syringe: 50,
          minConc: 0,
          maxConc: 50,
          minConcMsg: '',
          maxConcMsg:
              'Higher than recommended concentration of 1mg / ml (Medusa 2015; BNF).',
          minDose: 30,
          maxDose: 300,
          doseMsg: 'Usual dose 10-60 mcg/kg/hr'),
      Infusion(
          types: [DrugType.generic],
          name: 'generic',
          units: 'mcg/kg/hr',
          startDose: 0,
          fluids: [FluidType.D5W, FluidType.NS],
          desiredRate: 1,
          syringe: 50,
          minConc: 0,
          maxConc: 99999999,
          minConcMsg: '',
          maxConcMsg: '',
          minDose: 0,
          maxDose: 999999999,
          doseMsg: 'Please check units carefully.'),
      Infusion(
          types: [DrugType.generic],
          name: 'daily',
          units: 'mg/kg/day',
          startDose: 0,
          fluids: [FluidType.D5W, FluidType.NS],
          desiredRate: 1,
          syringe: 50,
          minConc: 0,
          maxConc: 99999999,
          minConcMsg: '',
          maxConcMsg: '',
          minDose: 0,
          maxDose: 999999999,
          doseMsg: '<Please check units carefully.')
    ];

    const weightEstimates = {
      23: 587,
      24: 686,
      25: 789,
      26: 896,
      27: 1007,
      28: 1125,
      29: 1253,
      30: 1398,
      31: 1565,
      32: 1756,
      33: 1966,
      34: 2191,
      35: 2423,
      36: 2658,
      37: 2888,
      38: 3106,
      39: 3307,
      40: 3484,
      41: 3636,
      42: 3772
    };

    /*Source: 50th centile average birthweight of male/female infants, using RCPCH UK–WHO Neonatal and Infant Close Monitoring Growth Chart 2009
    Cole TJ, Freeman JV, Preece MA. British 1990 growth reference centiles for weight, height, body mass index and head circumference fitted by maximum penalized likelihood.
    Stat.Med. 1998;17:407-29.*/
  }

  bool estimateWeight(int gestation) {
    if (gestation < 23 || gestation > 42) {
      babyWeight = double.nan;
      return false;
    } else {
      // Lots of fiddling for type and null safety
      babyWeight = weightEstimates[gestation] ?? double.nan;
      if (!babyWeight.isNaN) {
        babyWeight = babyWeight / 1000;
        return true;
      } else {
        return false;
      }
    }
  }

  bool setWeightGrams(double newWeightGrams) {
    double newWeight = newWeightGrams / 1000;
    if (newWeight > minWeight && newWeight < maxWeight) {
      babyWeight = newWeight;
      print('New weight in class $babyWeight');
      return true;
    } else {
      babyWeight = double.nan;
      return false;
    }
  }

  String weightString() {
    if (babyWeight.isNaN) {
      return 'Please enter a weight';
    } else {
      return weightIsEst
          ? '${babyWeight * 1000} g (Estimated)'
          : '${babyWeight * 1000} g';
    }
  }

  String weightStringShort() {
    if (babyWeight.isNaN) {
      return '';
    } else {
      return (babyWeight * 1000).round().toString();
    }
  }

  double weightNumGrams() {
    return babyWeight * 1000;
  }

  List<Drug> drugList(DrugType myType) {
    // Find all the drugs of a given type
    // Then return a list of new Drugs with the weight bound in
    print("DrugDb len: ${drugDb.length}");
    var myList = drugDb.where((drug) => drug.types.contains(myType));
    List<Drug> newList = [];
    for (var drug in myList) {
      newList.add(drug.bindWeight(babyWeight));
    }
    print("Druglist len: ${newList.length}");
    return newList;
  }

  String ettSizeString() {
    if (babyWeight.isNaN) {
      return 'Please enter a weight';
    }
    if (babyWeight < 1) {
      return '2.5';
    }
    if (babyWeight >= 1 && babyWeight < 2) {
      return '3.0';
    }
    if (babyWeight >= 2 && babyWeight < 3) {
      return '3.5';
    }
    return '3.5 - 4.0';
  }

  String ettDepthString() {
    if (babyWeight.isNaN) {
      return 'Please enter a weight';
    }
    if (babyWeight < 0.5) {
      return '5.5 cm';
    }
    if (babyWeight >= 0.5 && babyWeight < 0.7) {
      return '5.5 cm';
    }
    if (babyWeight >= 0.7 && babyWeight < 0.9) {
      return '6.0 cm';
    }
    if (babyWeight >= 0.9 && babyWeight < 1.1) {
      return '6.5 cm';
    }
    if (babyWeight >= 1.1 && babyWeight < 1.5) {
      return '7.0 cm';
    }
    if (babyWeight >= 1.5 && babyWeight < 1.9) {
      return '7.5 cm';
    }
    if (babyWeight >= 1.9 && babyWeight < 2.5) {
      return '8.0 cm';
    }
    if (babyWeight >= 2.5 && babyWeight < 3.2) {
      return '8.5 cm';
    }
    if (babyWeight >= 3.2 && babyWeight <= 4.2) {
      return '9.0 cm';
    }
    return 'N/A';
  }
}
